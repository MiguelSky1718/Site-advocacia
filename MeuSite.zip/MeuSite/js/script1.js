document.getElementById('consultation-form').addEventListener('submit', function(event) {
    event.preventDefault();  // Impede o envio padrão

    // Simulação de envio (substitua por lógica de envio real se necessário)
    setTimeout(() => {
        // Exibe o popup de sucesso
        document.getElementById('popup-success').style.display = 'block';
        this.reset();  // Limpa o formulário
    }, 500);  // Simula envio com atraso de 0,5s
});

// Fecha o popup ao clicar no "X"
document.querySelector('.close-popup').addEventListener('click', function() {
    document.getElementById('popup-success').style.display = 'none';
});
